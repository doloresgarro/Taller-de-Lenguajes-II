package Ejercicio3;

public enum TipoAfinacion {
	DO, RE, SI, LA;
}
